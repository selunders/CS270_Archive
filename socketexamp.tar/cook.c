#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>                /* for sockaddr_un struct */

#define DEFAULT_PROTOCOL    0

/****************************************************************/

main ()

{
  int clientFd, serverLen, result;
  struct sockaddr_un serverAddress;
  struct sockaddr* serverSockAddrPtr;

  serverSockAddrPtr = (struct sockaddr*) &serverAddress;
  serverLen = sizeof (serverAddress);

  /* Create a socket, bidirectional, default protocol */
  clientFd = socket (PF_LOCAL, SOCK_STREAM, DEFAULT_PROTOCOL);
  serverAddress.sun_family = PF_LOCAL; /* Server domain */
  strcpy (serverAddress.sun_path, "recipe"); /* Server name */

  do /* Loop until a connection is made with the server */
    {
      result = connect (clientFd, serverSockAddrPtr, serverLen);
      if (result == -1) sleep (1); /* Wait and then try again */
    }
  while (result == -1);

  readRecipe (clientFd); /* Read the recipe */
  close (clientFd); /* Close the socket */
  exit (/* EXIT_SUCCESS */ 0); /* Done */
}

/**************************************************************/

readRecipe (fd)

int fd;

{
  char str[200];

  while (readLine (fd, str)) /* Read lines until end-of-input */
    printf ("%s\n", str); /* Echo line from socket */
}

/**************************************************************/

readLine (fd, str)

int fd;
char* str;

/* Read a single NULL-terminated line */

{
  int n;

  do /* Read characters until NULL or end-of-input */
    {
      n = read (fd,str, 1); /* Read one character */
    }
  while (n > 0 && *str++ != 0);
  return (n > 0); /* Return false if end-of-input */
}
